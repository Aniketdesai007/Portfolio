import React from 'react'
import headerstyle from "./headerstyle.css"

const HeaderComp = () => {
  return (
    <>
    <div class="header">
  <a href="#default" class="logo">CompanyLogo</a>
  <div class="header-right">
    <a class="active" href="#home">Home</a>
    <a href="#contact">Contact</a>
    <a href="#about">About</a>
  </div>
</div>

<div >
  <h1>Responsive Header</h1>
  <p>Resize the browser window to see the effect.</p>
  <p>Some content..</p>
</div>
    </>
  )
}

export default HeaderComp