import HeaderComp from "./components/HeaderComp";

function App() {
  return (
    <>
      <HeaderComp />
    </>
  );
}

export default App;
