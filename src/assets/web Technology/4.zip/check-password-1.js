function ValidateEmail(inputText)
{
var mailformat = /^[a-zA-Z0-9!_@#$%^&*]{6,16}$/;
if(inputText.value.match(mailformat))
{
alert("Valid password");
document.form1.text1.focus();
return true;
}
else
{
alert("You have entered an invalid password!");
document.form1.text1.focus();
return false;
}
}
